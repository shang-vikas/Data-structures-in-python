# packaging-test-repo
Learning the packaging, automatic testing using this repo

i<table>
    <tr>
            <td>License</td>
                    <td><img src='https://img.shields.io/pypi/l/reurl.svg'></td>
                            <td>Version</td>
                                    <td><img src='https://img.shields.io/pypi/v/reurl.svg'></td>
                                        </tr>
                                            <tr>
                                                    <td>Travis CI</td>
                                                            <td><img src='https://travis-ci.org/reaper-shin/reurl.svg?branch=master'></td>
                                                                    <td>Coverage</td>
                                                                            <td><img src='https://codecov.io/gh/reaper-shin/reurl/branch/master/graph/badge.svg'></td>
                                                                                </tr>
                                                                                    <tr>
                                                                                            <td>Wheel</td>
                                                                                                    <td><img src='https://img.shields.io/pypi/wheel/reurl.svg'></td>
                                                                                                            <td>Implementation</td>
                                                                                                                    <td><img src='https://img.shields.io/pypi/implementation/reurl.svg'></td>
                                                                                                                        </tr>
                                                                                                                            <tr>
                                                                                                                                    <td>Status</td>
                                                                                                                                            <td><img src='https://img.shields.io/pypi/status/reurl.svg'></td>
                                                                                                                                                    <td>Downloads</td>
                                                                                                                                                            <td><img src='https://img.shields.io/pypi/dm/reurl.svg'></td>
                                                                                                                                                                </tr>
                                                                                                                                                                    <tr>
                                                                                                                                                                            <td>Supported versions</td>
                                                                                                                                                                                    <td><img src='https://img.shields.io/pypi/pyversions/reurl.svg'></td>
                                                                                                                                                                                        </tr>
                                                                                                                                                                                        </table>
